package inheritence;

public class Elementaryschool extends Student{
	public Elementaryschool() {
		// TODO Auto-generated constructor stub
	}
	
}
