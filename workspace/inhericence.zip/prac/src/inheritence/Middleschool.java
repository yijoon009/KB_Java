package inheritence;

public class Middleschool extends Student{
	String teacher;
	int attend;
	int service;
	public Middleschool() {
		// TODO Auto-generated constructor stub
	}
	public Middleschool(String name, int realScore, int mid, int final_test, int suhang, String teacher, int attend,
			int service) {
		super(name, realScore, mid, final_test, suhang);
		this.teacher = teacher;
		this.attend = attend;
		this.service = service;
	}
	
}
