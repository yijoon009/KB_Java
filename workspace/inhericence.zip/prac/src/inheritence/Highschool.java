package inheritence;

public class Highschool extends Student{
	String teacher;
	int attend;
	int service;
	double pyojun;
	
	public Highschool() {
		// TODO Auto-generated constructor stub
	}

	public Highschool(String name, int realScore, int mid, int final_test, int suhang, String teacher, int attend,
			int service, double pyojun) {
		super(name, realScore, mid, final_test, suhang);
		this.teacher = teacher;
		this.attend = attend;
		this.service = service;
		this.pyojun = pyojun;
	}
	
}
