package ver1;

public class AuthenException extends Exception{
	public AuthenException(String message) {
		super(message);
		}
	
}
