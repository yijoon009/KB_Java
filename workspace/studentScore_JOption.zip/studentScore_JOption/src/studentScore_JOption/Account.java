package studentScore_JOption;

public class Account {
	private String id;
	private String pw;
	private String school;
	private String grade;
	private String class_name;
	
	public Account() {;}
	
	public String getId() {return id;}
	public void setId(String id) {this.id = id;}
	public String getPw() {return pw;}
	public void setPw(String pw) {this.pw = pw;}
	public String getSchool() {return school;}
	public void setSchool(String school) {this.school = school;}
	public String getGrade() {return grade;}
	public void setGrade(String grade) {this.grade = grade;}
	public String getClass_name() {return class_name;}
	public void setClass_name(String class_name) {this.class_name = class_name;}
	
}
