package studentScore_JOption;

public class Main  {
	public static void main(String[] args){
		new Field().startView();
	}//end main
}
