// 부모 class
public class MakeupProduct {
	double price;
	int mcnt = 0; // 개수
	
	public MakeupProduct(){}
	public MakeupProduct(double price) {this.price=((price+(price*0.5)));}
	
}

class Lipstic extends MakeupProduct{
	public Lipstic() {super(2000);}
	
	public String toString() {return "립스틱";}
}
class Soap extends MakeupProduct{
	public Soap() {super(500);}
	@Override
	public String toString() {return "비누";}
}
class Shampoo extends MakeupProduct{
	public Shampoo() {super(1000);}
	@Override
	public String toString() {return "샴푸";}
}